package uk.ac.bris.cs.scotlandyard.ui.ai;

import java.util.ArrayList;
import java.util.Random;
import java.util.Set;
import java.util.function.Consumer;

import uk.ac.bris.cs.gamekit.graph.Graph;
import uk.ac.bris.cs.gamekit.graph.ImmutableGraph;
import uk.ac.bris.cs.gamekit.graph.Edge;
import uk.ac.bris.cs.gamekit.graph.Node;
import uk.ac.bris.cs.scotlandyard.ai.ManagedAI;
import uk.ac.bris.cs.scotlandyard.ai.PlayerFactory;
import uk.ac.bris.cs.scotlandyard.model.Colour;

import static java.util.Arrays.asList;
import static java.util.Collections.emptySet;
import static java.util.Collections.singletonList;
import static java.util.Collections.unmodifiableCollection;
import static java.util.Collections.unmodifiableList;
import static java.util.Collections.unmodifiableSet;

//import static org.junit.Assert.assertNotNull;
import static java.util.Objects.requireNonNull;
import static uk.ac.bris.cs.scotlandyard.model.Colour.BLACK;
import uk.ac.bris.cs.scotlandyard.model.Move;
import uk.ac.bris.cs.scotlandyard.model.Player;
import uk.ac.bris.cs.scotlandyard.model.ScotlandYardPlayer;

import static uk.ac.bris.cs.scotlandyard.model.Ticket.SECRET;
import static uk.ac.bris.cs.scotlandyard.model.Ticket.TAXI;
import uk.ac.bris.cs.scotlandyard.model.ScotlandYardView;
import uk.ac.bris.cs.scotlandyard.model.Ticket;
import uk.ac.bris.cs.scotlandyard.model.MoveVisitor;
import uk.ac.bris.cs.scotlandyard.model.DoubleMove;
import uk.ac.bris.cs.scotlandyard.model.TicketMove;
import uk.ac.bris.cs.scotlandyard.model.Transport;

import java.util.ArrayList;
import java.util.Optional;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;


// TODO name the AI
@ManagedAI("Mr X AI")
public class MrXAI implements PlayerFactory{

	// TODO create a new player here
	@Override
	public Player createPlayer(Colour colour) {
		return new MyPlayer();
	}

	// TODO A sample player that selects a random move
	private static class MyPlayer implements Player, MoveVisitor{
		private TicketMove tempTicketMove;
		
		@Override
		public void makeMove(ScotlandYardView view, int location, Set<Move> moves,
				Consumer<Move> callback) {
			
			final List<Move> origionalMoves = new ArrayList<Move>(moves);
			final List<Colour> players = view.getPlayers();
	
			Move moveToMake = origionalMoves.get(0);
			double tempScore = 0;
			double score = 0;
			for (Move possibleMove : moves) {
				possibleMove.visit(this);
				//work out distance to all detectives
				//work out how many moves can be made from new location
				//basic score for each move
				tempScore = (0.7 * distanceFromNearestDetective(tempTicketMove, players, view, location)) * (0.3 * numberOfMovesAvailableFromNewLocation(view, location, players));
				if (tempScore > score) {
					score = tempScore;
					moveToMake = possibleMove;
				}				
			}		
			callback.accept(moveToMake);
		}
		
		@Override
		public void visit(DoubleMove move) {
			visit(move.secondMove());
		}
		
		@Override
		public void visit(TicketMove move) {
			tempTicketMove = move;
		}
		
		private int distanceFromNearestDetective(TicketMove move, List<Colour> players, ScotlandYardView view, int mrXLoc) {
			int distance = 200;
			int tempDistance;
			int tempLocation;
			for (Colour player : players) {
				if(player != BLACK) {
					tempLocation = view.getPlayerLocation(player).get();
					tempDistance = djikstraNoOfNodesAway(tempLocation, mrXLoc, view);
					if (tempDistance < distance) distance = tempDistance;
				}
			}
			return distance;
		}
		
		private int djikstraNoOfNodesAway(int detLoc, int mrXLoc, ScotlandYardView view) {
			//want number of nodes between us and closest detective.
			//enter in our location and then go through each detective in turn and use Djikstra to 
			//find distance
			ImmutableGraph<Integer, Transport> ourGraph = new ImmutableGraph<>(view.getGraph());
			Node<Integer> startNode = new Node<Integer>(mrXLoc);
			Node<Integer> targetNode = new Node<Integer>(detLoc);
			List<Node<Integer>> visited = new ArrayList<Node<Integer>>();
			List<Node<Integer>> neighbours = new ArrayList<Node<Integer>>(addNeighbourNodes(ourGraph, startNode));
			
			boolean detFound = false;
			int countSteps = 0;
			
			while(detFound == false) {
				countSteps ++;
				visited.addAll(neighbours);
				neighbours.clear();
				if (visited.contains(targetNode)) detFound = true;
				else {
					for(Node<Integer> node : visited) {
						neighbours.addAll(addNeighbourNodes(ourGraph, node));
					}
				}
			}	
			
			return countSteps;
		}

		private List<Node<Integer>> addNeighbourNodes(Graph<Integer, Transport> ourGraph, Node<Integer> startNode){
			requireNonNull(startNode);
			List<Node<Integer>> temp = new ArrayList<Node<Integer>>();
			Collection<Edge<Integer, Transport>> edges = ourGraph.getEdgesFrom(startNode);
			for (Edge<Integer,Transport> edge : edges) {
				temp.add(edge.destination());
			}
			return temp;
		}
		
		
		
		
		private int numberOfMovesAvailableFromNewLocation(ScotlandYardView view, int location, List<Colour> players) {
			int numberOfAvailableMoves = ticketMoves(location, view, players).size();
			return numberOfAvailableMoves;
		}
		
		
		//creates and returns all the valid ticket moves that can be made
		private Set<Move> ticketMoves(Integer location, ScotlandYardView view, List<Colour> players){	
			Set<Move> allTicketMoves = new HashSet<>();
			Node<Integer> sourceNode = new Node<Integer>(location);
			Collection<Edge<Integer, Transport>> connectedEdges = view.getGraph().getEdgesFrom(sourceNode);		
			for(Edge<Integer, Transport> x : connectedEdges) {
				if (checkNodeIsEmpty(x, players, view)) {
					if(view.getPlayerTickets(BLACK, Ticket.fromTransport(x.data())).get() != 0) {
						TicketMove temp = new TicketMove(BLACK, Ticket.fromTransport(x.data()), x.destination().value());
						allTicketMoves.add(temp);
					}
					if(view.getPlayerTickets(BLACK, SECRET).get() != 0) {
						TicketMove secretTemp = new TicketMove(BLACK, Ticket.SECRET, x.destination().value());
						allTicketMoves.add(secretTemp);
					}
				}
			}		
			return allTicketMoves;
		}
		
		//checks to see if a destination node is currently occupied
		private boolean checkNodeIsEmpty(Edge<Integer, Transport> edge, List<Colour> players, ScotlandYardView view) {
			for (Colour x : players) {
				if (x != BLACK) {
					if (view.getPlayerLocation(x).get() == edge.destination().value()) return false;
				}
			}
			return true;
		}
		
		
		
	}
}

